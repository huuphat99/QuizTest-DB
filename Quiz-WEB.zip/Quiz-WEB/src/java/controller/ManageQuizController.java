package controller;

import dal.QuizDAO;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Quiz;

public class ManageQuizController extends BaseController {

    @Override
    protected void handleGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            //check if user's logged in as teacher role
            HttpSession session = request.getSession();
            Object oTypeID = session.getAttribute("typeID");
            if (oTypeID == null || Integer.parseInt(oTypeID.toString()) != 2) {
                getServletContext().getRequestDispatcher("/LimitedAccessPage.jsp").forward(request, response);
                return;
            }

            QuizDAO qDB = new QuizDAO();
            ArrayList<Quiz> quizzes;

            int creatorID = (int) request.getSession().getAttribute("userID");
            quizzes = qDB.getData(creatorID);
            request.setAttribute("quizzes", quizzes);

            //for display purpose only
            int totalRecords = qDB.countRecords(creatorID);

            if (totalRecords == 0) {

                System.out.println("no dang chay vao day");
                getServletContext().getRequestDispatcher("/WEB-INF/ManageQuiz2.jsp").forward(request, response);
                return;
            }
            
            // nếu người user không create câu hỏi thì sẽ chuyển tới trang Manage Quiz để thông báo k có câu hỏi nào đc tạo

            request.setAttribute("totalRecords", totalRecords);
            getServletContext().getRequestDispatcher("/WEB-INF/ManageQuiz.jsp").forward(request, response);
        } catch (Exception ex) {
            Logger.getLogger(ManageQuizController.class.getName()).log(Level.SEVERE, null, ex);
            getServletContext().getRequestDispatcher("/ErrorPage.jsp").forward(request, response);
        }
    }

    @Override
    protected void handlePost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
