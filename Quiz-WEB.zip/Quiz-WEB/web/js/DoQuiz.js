var timeLeft = parseInt(document.querySelector("#timeElapsed").value);
var timer = document.getElementById("timer");
timer.value = timeLeft;
var result = document.getElementById("result");
result.value = "";
var options = document.querySelectorAll(".options");
var btnSubmit = document.querySelector("#btnSubmit");

function countdown() {
    var x = setInterval(function () {
        var y = setInterval(function() {
            setResult();
        },10);
        timer.innerHTML = timeLeft;
        timeLeft--;
        if (timeLeft < 0) {
            clearInterval(x);
//            timer.innerHTML = "Time out";
            btnSubmit.click();
           
        }
        console.log("result: " + result.value);
//        calculator();
        
    }, 1000);
}
function setResult() {
    result.value = "";
    for (var i = 0; i < options.length; i++) {
        if (options[i].checked) {
            result.value += options[i].value;
        }
    }
//    if (result.value === "") {
//        result.value = "timeout";
//    }
}