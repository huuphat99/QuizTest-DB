function takeTest() {
    window.location.href = "takequiz";
}