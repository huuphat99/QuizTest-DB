alert("Only teacher can use this function");
window.location.href = "Home.jsp";